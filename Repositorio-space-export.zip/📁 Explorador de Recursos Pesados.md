# 📁 Explorador de Recursos Pesados

## Para poder administrar los archivos seguros y recursos publicados:

### https://diftel.josnic.cl/filebrowser/login

## Para poder copiar links rápidamente:

https://diftel.josnic.cl/recursos/

```

```