# MAT043 (ELO204) Teoría de Probabilidad y Aplicaciones

# MAT043 (ELO204) Teoría de Probabilidad y Aplicaciones

Este es el repositorio central para la asignatura de **MAT043 Teoría de Probabilidad y Aplicaciones**. Aquí encontrarás apuntes, guías y material de estudio aportado por la comunidad.

:::info
🤓 ☝️ **_En la malla oficial se utiliza ELO204, pero en CSSJ no se imparte tal ramo hace tiempo. En cambio se rinde el ramo equivalente MAT043._**
:::

---

### 📝 Resúmenes y Apuntes

_(Aún no hay apuntes subidos. ¡Sé el primero en aportar a través del_ [_Buzón_](https://diftel.josnic.cl/buzon/)_!)_

### 📝 Certámenes Pasados

_(Espacio para pautas y certámenes anteriores)_