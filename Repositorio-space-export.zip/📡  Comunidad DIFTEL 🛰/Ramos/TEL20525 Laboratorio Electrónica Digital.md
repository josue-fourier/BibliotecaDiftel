# TEL20525 Laboratorio Electrónica Digital

# TEL20525 Laboratorio Electrónica Digital

Este es el repositorio central para la asignatura de **TEL20525 Laboratorio Electrónica Digital**. Aquí encontrarás apuntes, guías y material de estudio aportado por la comunidad.

---

### 📝 Resúmenes y Apuntes

_(Aún no hay apuntes subidos. ¡Sé el primero en aportar a través del_ [_Buzón_](https://diftel.josnic.cl/buzon/)_!)_

### 📝 Certámenes Pasados

_(Espacio para pautas y certámenes anteriores)_