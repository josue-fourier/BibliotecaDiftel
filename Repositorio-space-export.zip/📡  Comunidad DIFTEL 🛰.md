# 📡 Comunidad DIFTEL 🛰️

## Enlaces Rápidos  
🏠[Volver al Inicio](https://diftel.josnic.cl/) | 📤 [Ir al Buzón Seguro](https://diftel.josnic.cl/buzon/)

**¡Bienvenido al cerebro digital de Telemática SJ! 🧠⚡**  
**Este repositorio colaborativo agrupa material académico validado para nuestra comunidad.**

⚠️ Actualmente en proceso de inicialización - Hay fallos en los ramos de las mallas, aún no hay material ⚠️

---

## 🗺️ Navega tu Malla

Explora los recursos ordenados por asignatura:

- 📚 [Malla Nueva](%F0%9F%93%A1%20%20Comunidad%20DIFTEL%20%F0%9F%9B%B0%EF%B8%8F/Mallas/%F0%9F%97%BA%EF%B8%8F%20Malla%20Nueva.md)
- 🏛️ [Malla Antigua](%F0%9F%93%A1%20%20Comunidad%20DIFTEL%20%F0%9F%9B%B0%EF%B8%8F/Mallas/%F0%9F%97%BA%EF%B8%8F%20Malla%20Antigua.md)

---

## 🤝 ¿Cómo Contribuir?

¡Tú haces que esta biblioteca crezca! Hay **dos formas** de ayudar:

### Opción A: Donar Material 📤 (Fácil y Rápido)

Ideal si tienes pruebas, resúmenes o PDFs pesados:

1. Sube tu archivo al [Buzón Seguro](https://diftel.josnic.cl/buzon/) (Máx 2 GB, usa `.zip` si son varios).
2. Nuestro antivirus lo revisará 🛡️.
3. Si está limpio, ¡el equipo de mantención se encargará del resto!

### Opción B: Escribir y Categorizar Apuntes ✍️ (Modo Pro)

Ideal si quieres organizar las mallas o crear guías de estudio usando Markdown:

1. Escríbe al correo visible a lo último de esta página, o si me conoces, contáctame por algún medio en común.
2. Luego, si a mí y/o al grupo de mantención le parece, se te contactará para entregarte los accesos pertinentes para contribuir.

**Para cualquier contribución, se te añadirá en los créditos a continuación.**

---

## ⭐ Créditos

#### Mantenedores

- Josué Leiva (Gen 2024)
- Sebastián Saldías (Gen 2024)

#### Aportes de Material

- Tú podrías ser el siguiente…

---

_Creado por Josué Leiva Poblete - jleivap \[at\] usm \[dot\] cl_